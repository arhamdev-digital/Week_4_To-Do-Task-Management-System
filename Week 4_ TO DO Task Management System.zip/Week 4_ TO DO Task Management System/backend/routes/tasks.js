import {Router} from "express";
import {getDB} from "../config/db.js";
import {protect} from "../middleware/auth.js";
const router=Router();router.use(protect);
const fields="id,title,description,status,due_date AS dueDate,created_at AS createdAt";
router.get("/",async(req,res)=>{try{const [tasks]=await getDB().execute(`SELECT ${fields} FROM tasks WHERE user_id=? ORDER BY created_at DESC`,[req.user.id]);res.json({tasks});}catch(e){console.error("Get tasks:",e);res.status(500).json({message:"Could not load tasks."});}});
router.post("/",async(req,res)=>{try{
 const {title,description="",dueDate=null}=req.body;if(!title?.trim())return res.status(400).json({message:"Task title is required."});
 const [r]=await getDB().execute("INSERT INTO tasks(user_id,title,description,due_date) VALUES(?,?,?,?)",[req.user.id,title.trim(),description,dueDate||null]);
 const [rows]=await getDB().execute(`SELECT ${fields} FROM tasks WHERE id=? AND user_id=?`,[r.insertId,req.user.id]);res.status(201).json({task:rows[0]});
 }catch(e){console.error("Create task error:",e);res.status(500).json({message:"Could not create task. Check backend terminal."});}});
router.put("/:id",async(req,res)=>{try{
 const {title,description="",status,dueDate=null}=req.body;
 if(!title?.trim())return res.status(400).json({message:"Task title is required."});
 if(!["pending","completed"].includes(status))return res.status(400).json({message:"Invalid status."});
 const [r]=await getDB().execute("UPDATE tasks SET title=?,description=?,status=?,due_date=? WHERE id=? AND user_id=?",[title.trim(),description,status,dueDate||null,req.params.id,req.user.id]);
 if(!r.affectedRows)return res.status(404).json({message:"Task not found."});
 const [rows]=await getDB().execute(`SELECT ${fields} FROM tasks WHERE id=? AND user_id=?`,[req.params.id,req.user.id]);res.json({task:rows[0]});
 }catch(e){console.error("Update task:",e);res.status(500).json({message:"Could not update task."});}});
router.delete("/:id",async(req,res)=>{try{const [r]=await getDB().execute("DELETE FROM tasks WHERE id=? AND user_id=?",[req.params.id,req.user.id]);if(!r.affectedRows)return res.status(404).json({message:"Task not found."});res.json({message:"Task deleted."});}catch(e){console.error("Delete task:",e);res.status(500).json({message:"Could not delete task."});}});
export default router;
