import {Router} from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import {getDB} from "../config/db.js";
const router=Router();
const tokenFor=u=>jwt.sign({id:u.id,email:u.email},process.env.JWT_SECRET,{expiresIn:"7d"});
router.post("/register",async(req,res)=>{
 try{
  const {name,email,password}=req.body;
  if(!name?.trim()||!email?.trim()||!password)return res.status(400).json({message:"Name, email and password are required."});
  if(password.length<6)return res.status(400).json({message:"Password must be at least 6 characters."});
  const mail=email.trim().toLowerCase(),db=getDB();
  const [found]=await db.execute("SELECT id FROM users WHERE email=?",[mail]);
  if(found.length)return res.status(409).json({message:"Email already registered. Please log in."});
  const hash=await bcrypt.hash(password,10);
  const [r]=await db.execute("INSERT INTO users(name,email,password) VALUES(?,?,?)",[name.trim(),mail,hash]);
  const user={id:r.insertId,name:name.trim(),email:mail};
  res.status(201).json({token:tokenFor(user),user});
 }catch(e){console.error("Register error:",e);res.status(500).json({message:"Could not create account."});}
});
router.post("/login",async(req,res)=>{
 try{
  const {email,password}=req.body;if(!email||!password)return res.status(400).json({message:"Email and password are required."});
  const [rows]=await getDB().execute("SELECT id,name,email,password FROM users WHERE email=?",[email.trim().toLowerCase()]);
  if(!rows.length||!(await bcrypt.compare(password,rows[0].password)))return res.status(401).json({message:"Incorrect email or password."});
  const user={id:rows[0].id,name:rows[0].name,email:rows[0].email};res.json({token:tokenFor(user),user});
 }catch(e){console.error("Login error:",e);res.status(500).json({message:"Could not log in."});}
});
export default router;
