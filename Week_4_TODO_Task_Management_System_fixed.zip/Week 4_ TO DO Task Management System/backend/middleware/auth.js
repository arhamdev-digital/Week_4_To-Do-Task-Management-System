import jwt from "jsonwebtoken";
export function protect(req,res,next){
 const h=req.headers.authorization||""; const token=h.startsWith("Bearer ")?h.slice(7):null;
 if(!token)return res.status(401).json({message:"Please log in first."});
 try{req.user=jwt.verify(token,process.env.JWT_SECRET);next();}
 catch{return res.status(401).json({message:"Session expired. Please log in again."});}
}
