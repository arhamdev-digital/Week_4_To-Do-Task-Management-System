import "dotenv/config";
import express from "express";
import cors from "cors";
import {connectDB} from "./config/db.js";
import authRoutes from "./routes/auth.js";
import taskRoutes from "./routes/tasks.js";
if(!process.env.JWT_SECRET){console.error("JWT_SECRET is missing in backend/.env");process.exit(1);}
const app=express();
app.use(cors({origin:process.env.CLIENT_URL||"http://localhost:5173"}));
app.use(express.json());
app.get("/api/health",(_req,res)=>res.json({status:"ok",message:"TaskFlow API is running."}));
app.use("/api/auth",authRoutes);app.use("/api/tasks",taskRoutes);
const PORT=Number(process.env.PORT||5000);
try{await connectDB();app.listen(PORT,()=>console.log(`Server running on http://localhost:${PORT}`));}
catch(e){console.error("MySQL startup failed:",e.message);process.exit(1);}
