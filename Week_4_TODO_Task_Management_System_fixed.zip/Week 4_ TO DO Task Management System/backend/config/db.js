import mysql from "mysql2/promise";
let pool;
export async function connectDB() {
  const cfg={host:process.env.DB_HOST||"localhost",port:Number(process.env.DB_PORT||3306),user:process.env.DB_USER||"root",password:process.env.DB_PASSWORD||""};
  const conn=await mysql.createConnection(cfg);
  const db=(process.env.DB_NAME||"taskflow_db").replace(/`/g,"");
  await conn.query(`CREATE DATABASE IF NOT EXISTS \`${db}\``); await conn.end();
  pool=mysql.createPool({...cfg,database:db,waitForConnections:true,connectionLimit:10});
  await pool.query(`CREATE TABLE IF NOT EXISTS users(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,email VARCHAR(190) NOT NULL UNIQUE,password VARCHAR(255) NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`);
  await pool.query(`CREATE TABLE IF NOT EXISTS tasks(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,title VARCHAR(200) NOT NULL,description TEXT,status ENUM('pending','completed') NOT NULL DEFAULT 'pending',due_date DATE NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,CONSTRAINT fk_tasks_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)`);
  console.log("MySQL connected"); console.log("Database and tables are ready"); return pool;
}
export function getDB(){if(!pool) throw new Error("Database is not initialized"); return pool;}
